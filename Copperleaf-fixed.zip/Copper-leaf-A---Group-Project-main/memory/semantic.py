"""Backward-compatible import for the Memory/RAG agent."""
from .semantic_memory import SemanticMemory

__all__ = ["SemanticMemory"]
