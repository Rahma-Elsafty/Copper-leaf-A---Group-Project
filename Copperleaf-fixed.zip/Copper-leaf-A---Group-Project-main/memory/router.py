"""Compatibility facade around the project's Promote-or-Drop router."""
from .routing import PromoteOrDropRouter as _PromoteOrDropRouter
from .schemas import MemoryItem

class PromoteOrDropRouter(_PromoteOrDropRouter):
    def decide(self, item):
        if isinstance(item, MemoryItem):
            memory_item = item
        elif isinstance(item, dict):
            memory_item = MemoryItem(role="user", content=str(item.get("answer") or item.get("query") or item))
        else:
            memory_item = MemoryItem(role="user", content=str(item))

        try:
            return self.route(memory_item, user_id="platform-user").model_dump()
        except Exception:
            return {
                "decision": "forget",
                "reason": "Memory router unavailable.",
            }

__all__ = ["PromoteOrDropRouter"]
