"""Small scratchpad object used by the platform Memory/RAG chat agent."""

class Scratchpad:
    def __init__(self):
        self.state = {
            "current_goal": None,
            "current_subgoal": None,
            "working_state": {},
        }

    def update(self, current_goal=None, current_subgoal=None, working_state=None):
        if current_goal is not None:
            self.state["current_goal"] = current_goal
        if current_subgoal is not None:
            self.state["current_subgoal"] = current_subgoal
        if working_state is not None:
            self.state["working_state"] = dict(working_state)
        return self.state

    def get(self):
        return dict(self.state)
