"""Single source of truth for the MCP tools exposed by Copperleaf.

The low-level MCP server keeps the actual handler implementations in
``tools_read.py`` and ``tools_write.py``.  This module contains only the
shared metadata used by the admin platform and other in-process callers.
"""

TOOL_DEFS = [
    {
        "name": "list_suppliers",
        "description": "Return all suppliers.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "get_supplier",
        "description": "Return a supplier by ID.",
        "inputSchema": {
            "type": "object",
            "properties": {"supplier_id": {"type": "integer"}},
            "required": ["supplier_id"],
        },
    },
    {
        "name": "list_low_stock_items",
        "description": "Return ingredients below reorder threshold.",
        "inputSchema": {
            "type": "object",
            "properties": {"location_id": {"type": "integer"}},
            "required": ["location_id"],
        },
    },
    {
        "name": "get_recipe_allergens",
        "description": "Return allergens for a menu item.",
        "inputSchema": {
            "type": "object",
            "properties": {"item_id": {"type": "integer"}},
            "required": ["item_id"],
        },
    },
    {
        "name": "place_purchase_order",
        "description": "Create a purchase order.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "ingredient_id": {"type": "integer"},
                "supplier_id": {"type": "integer"},
                "qty": {"type": "integer"},
                "unit_cost": {"type": "number"},
                "requested_by": {"type": "integer"},
            },
            "required": [
                "ingredient_id",
                "supplier_id",
                "qty",
                "unit_cost",
                "requested_by",
            ],
        },
    },
    {
        "name": "approve_purchase_order",
        "description": "Approve a purchase order.",
        "inputSchema": {
            "type": "object",
            "properties": {"po_id": {"type": "integer"}},
            "required": ["po_id"],
        },
    },
    {
        "name": "mark_supplier_verified",
        "description": "Verify a supplier.",
        "inputSchema": {
            "type": "object",
            "properties": {"supplier_id": {"type": "integer"}},
            "required": ["supplier_id"],
        },
    },
    {
        "name": "record_inventory_count",
        "description": "Update inventory quantity.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "stock_id": {"type": "integer"},
                "quantity": {"type": "integer"},
            },
            "required": ["stock_id", "quantity"],
        },
    },
]

TOOL_NAMES = [tool["name"] for tool in TOOL_DEFS]
