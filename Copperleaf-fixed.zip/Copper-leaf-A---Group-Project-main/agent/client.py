"""Platform-facing Memory/RAG agent.

The original checkout contained an older Memory/RAG client that referenced
module names and APIs from a different lab revision.  This version keeps the
same public idea but matches the files that are actually present in this
repository and exposes the synchronous ``handle_message`` method used by the
Flask platform.
"""
from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any

from dotenv import load_dotenv

from memory.episodic import EpisodicMemory
from memory.router import PromoteOrDropRouter
from memory.semantic import SemanticMemory
from memory.short_term import ShortTermMemory
from memory.scratchpad import Scratchpad

load_dotenv()


class LocalRAG:
    """Dependency-light lexical RAG over the repository's RAG text files.

    It deliberately does not download an embedding model when the platform is
    merely started.  The project's heavier Chroma/embedding pipeline remains
    available in ``rag/`` for the retrieval evaluation and can be used later.
    """

    def __init__(self, data_dir: str | Path = "rag/data"):
        self.documents: list[dict[str, Any]] = []
        root = Path(data_dir)
        if root.exists():
            for path in sorted(root.glob("*.txt")):
                text = path.read_text(encoding="utf-8", errors="ignore")
                self.documents.extend(self._chunk(path.name, text))

        # Include admin-managed RAG documents when the state-graph store is
        # available.  Failure here must not make the chat surface disappear.
        try:
            from state_graph import db as sg_db, store
            sg_db.ensure_schema()
            for row in store.list_rag_documents():
                self.documents.extend(self._chunk(row["title"], row["text"], {"doc_id": row["doc_id"], "source": "admin_rag_document"}))
        except Exception:
            pass

    @staticmethod
    def _chunk(title: str, text: str, metadata: dict[str, Any] | None = None):
        blocks = [b.strip() for b in re.split(r"\n\s*\n", text) if b.strip()]
        return [
            {"text": block, "metadata": {"title": title, **(metadata or {})}}
            for block in blocks
        ]

    @staticmethod
    def _tokens(text: str) -> set[str]:
        return set(re.findall(r"[a-zA-Z0-9']+", text.lower()))

    def search(self, query: str, k: int = 4) -> list[dict[str, Any]]:
        q = self._tokens(query)
        if not q:
            return []
        scored = []
        for doc in self.documents:
            tokens = self._tokens(doc["text"])
            overlap = len(q & tokens)
            if overlap:
                scored.append((overlap / max(1, len(q)), overlap, doc))
        scored.sort(key=lambda x: (x[0], x[1]), reverse=True)
        return [doc for _, _, doc in scored[:k]]


class CopperleafAgent:
    def __init__(self):
        self.short_term = ShortTermMemory(max_turns=10)
        self.scratchpad = Scratchpad()
        self.episodic = EpisodicMemory()
        self.semantic = SemanticMemory()
        self.router = PromoteOrDropRouter()
        self.rag = LocalRAG()

    def recall_memory(self, query: str) -> dict[str, list]:
        return {
            "episodic": self.episodic.search(query),
            "semantic": self.semantic.search(query),
        }

    def _generate(self, query: str, context: str) -> str:
        """Use OpenRouter when configured; otherwise return grounded evidence."""
        api_key = os.getenv("OPENROUTER_API_KEY")
        if api_key:
            try:
                from openai import OpenAI
                client = OpenAI(api_key=api_key, base_url="https://openrouter.ai/api/v1")
                response = client.responses.create(
                    model=os.getenv("COPPERLEAF_LLM_MODEL", "poolside/laguna-s-2.1:free"),
                    input=(
                        "Answer the user's question using ONLY the evidence below. "
                        "If the evidence is insufficient, say so.\n\n"
                        f"Question: {query}\n\nEvidence:\n{context}"
                    ),
                )
                text = getattr(response, "output_text", "").strip()
                if text:
                    return text
            except Exception:
                pass

        return "I found the following relevant information in the Copperleaf knowledge base:\n\n" + context

    def handle_message(self, message: str) -> str:
        query = (message or "").strip()
        if not query:
            return "Please enter a question."

        self.short_term.add("user", query)
        memory = self.recall_memory(query)
        self.scratchpad.update(
            current_goal=query,
            current_subgoal="Retrieve grounded evidence",
            working_state={
                "episodic_hits": len(memory["episodic"]),
                "semantic_hits": len(memory["semantic"]),
            },
        )

        docs = self.rag.search(query)
        if not docs:
            answer = "I could not find sufficiently relevant information in the Copperleaf knowledge base."
        else:
            context = "\n\n".join(doc["text"] for doc in docs)
            answer = self._generate(query, context)

        self.short_term.add("assistant", answer)
        self.episodic.add_episode("platform-user", query, {"answer": answer, "source": "memory_rag_agent"})
        return answer


def build_agent(session=None):
    """Compatibility helper retained for older callers."""
    return CopperleafAgent()
