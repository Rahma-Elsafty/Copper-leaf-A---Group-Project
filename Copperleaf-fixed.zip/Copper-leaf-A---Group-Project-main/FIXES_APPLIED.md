# Copperleaf integration fixes

This checkout was failing because the platform and Memory/RAG agent were copied from a different revision of the project.

## Fixed

- Added `mcp_server/tool_defs.py`, the shared MCP tool metadata expected by `platform/backend.py`.
- Added compatibility imports for the actual memory filenames:
  - `memory.short_term` -> `short_term_memory.py`
  - `memory.episodic` -> `episodic_memory.py`
  - `memory.semantic` -> `semantic_memory.py`
  - `memory.router` -> the actual `routing.py`
- Added the missing `memory.scratchpad` implementation used by the platform Memory/RAG chat agent.
- Fixed package-relative imports and prompt path handling in `memory/routing.py` and `memory/scratchpad_manager.py`.
- Reworked `agent/client.py` to match the APIs that actually exist in this repository and to expose `CopperleafAgent().handle_message(...)`, which the platform calls.
- The Memory/RAG chat uses the repository's `rag/data/*.txt` knowledge base and admin-managed RAG documents. If `OPENROUTER_API_KEY` is configured, it also uses the configured OpenRouter model to generate a grounded response; without a key it returns grounded evidence instead of crashing.
- Added `handle_message(...)` to the planning agent so the platform chat endpoint has the method it expects.
- Added the shared MCP tool registry to the MCP server and made the server honor the platform's per-agent tool permissions at list/call time.
- Removed generated Python caches from the deliverable.

## Run on Windows PowerShell

From the project root:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
pip install -r platform\requirements.txt
python platform\backend.py
```

Then open `http://localhost:5000` in a browser.

If PowerShell blocks activation, you can skip activation and run the venv interpreter directly:

```powershell
.\.venv\Scripts\python.exe platform\backend.py
```

For LLM-powered chat, create `.env` with at least:

```env
OPENROUTER_API_KEY=your_key_here
```

Optional:

```env
COPPERLEAF_LLM_MODEL=poolside/laguna-s-2.1:free
MCP_AGENT_NAME=default_agent
```

Do not commit `.env` or API keys.
